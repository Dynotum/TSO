
public class Instruccion {
	char CodigoOperacion;
	String Operando;
	
	public Instruccion(){
		CodigoOperacion = '0';
		Operando =  "000";
	}
}

