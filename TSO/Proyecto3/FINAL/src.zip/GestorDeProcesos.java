import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.*;

public class GestorDeProcesos{
	    
    int numeroDeProcesos;
    int cantidadInstrucciones;
    int inicioInstrucciones;
    int cantidadDatos;
    int inicioDatos;
    static int ultimo = -1;
    
    Instruccion instruccion = new Instruccion();
	String instruccionString ;
    
	String nombreArchivo;
	
	Vector<Proceso> Procesos = new Vector<Proceso>();
	Vector<Proceso> ProcesosListos = new Vector<Proceso>();
	Vector<Proceso> ProcesosBloqueados = new Vector<Proceso>();
	Vector<Proceso> ProcesosTerminados = new Vector<Proceso>();
	
	Vector<String> contadorPrograma = new Vector<String>();
	Vector<String> registroInstrucciones = new Vector<String>();
	Vector<String> acumulador = new Vector<String>();
	
	Proceso ProcesoEjecutando = new Proceso();
	
	Vector<String> instrucciones = new Vector<String>();
	Vector<String> datos = new Vector<String>();
	
	Interfaz Ventana = new Interfaz();

    public GestorDeProcesos(Memoria memoriaVirtual) throws IOException, InterruptedException {
        
        JFileChooser elegir = new JFileChooser();
        int opcion = elegir.showOpenDialog(elegir);
        
        nombreArchivo = elegir.getSelectedFile().getName();
        
        try {
        	File archivo = new File("archivo.txt");
            BufferedWriter bw;
			bw = new BufferedWriter(new FileWriter(archivo));
			bw.write("0000");
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        try {
        	File memoriaSecundaria = new File("memoriaSecundaria.txt");
            BufferedWriter bufferEscrituraMemoria;
			bufferEscrituraMemoria = new BufferedWriter(new FileWriter(memoriaSecundaria));
			bufferEscrituraMemoria.write("");
	        bufferEscrituraMemoria.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        leerArchivo(nombreArchivo);
        cargarProgramaMemoria(memoriaVirtual);
        Procesar(memoriaVirtual);
    }
    
    public void leerArchivo(String archivo) throws FileNotFoundException{
	    FileReader procesosEntrada = new FileReader(archivo);
	    BufferedReader bufferLectura = new BufferedReader(procesosEntrada);
	    try {
			numeroDeProcesos = Integer.parseInt(bufferLectura.readLine().trim());
			
			String dato;
			
			dato = bufferLectura.readLine();			
		    StringTokenizer instruccionesDelimitador = new StringTokenizer(dato,":");		    
		    cantidadInstrucciones = Integer.parseInt(instruccionesDelimitador.nextToken());
		    inicioInstrucciones = Integer.parseInt(instruccionesDelimitador.nextToken());
		    
		    dato = bufferLectura.readLine();			
		    StringTokenizer datosDelimitador = new StringTokenizer(dato,":");		    
		    cantidadDatos = Integer.parseInt(datosDelimitador.nextToken());
		    inicioDatos= Integer.parseInt(datosDelimitador.nextToken());
	    
		    int posicionProceso = inicioInstrucciones;
		    		
			for(int i = 0; i < numeroDeProcesos; i++){
				Proceso procesoTemporal = new Proceso();

				dato = bufferLectura.readLine();
				
			    StringTokenizer procesosDelimitador = new StringTokenizer(dato,":");
			    
			    procesoTemporal.idProceso = procesosDelimitador.nextToken();
			    procesoTemporal.numeroInstrucciones = Integer.parseInt(procesosDelimitador.nextToken());
			    procesoTemporal.prioridad = Integer.parseInt(procesosDelimitador.nextToken());
			    procesoTemporal.error = Integer.parseInt(procesosDelimitador.nextToken());
			    procesoTemporal.bloqueo = Integer.parseInt(procesosDelimitador.nextToken());
			    procesoTemporal.estado = 1;
			    procesoTemporal.posicionInstruccion = posicionProceso;
			    posicionProceso = procesoTemporal.numeroInstrucciones + posicionProceso;			    
			    
			    Procesos.add(procesoTemporal);
			    
			}
			
			bufferLectura.readLine();
			
			for(int i = 0; i < cantidadInstrucciones; i++){
				dato = bufferLectura.readLine();	
			    StringTokenizer instDelimitador = new StringTokenizer(dato,":");
			    instDelimitador.nextToken();
			    instrucciones.add(instDelimitador.nextToken());
		    }
		    
			bufferLectura.readLine();
			
		    for(int i = 0; i < cantidadDatos; i++){
		    	dato = bufferLectura.readLine();	
			    StringTokenizer instDelimitador = new StringTokenizer(dato,":");
			    instDelimitador.nextToken();
		    	datos.add(instDelimitador.nextToken());
		    }
			bufferLectura.close();	
	    }
	    catch (NumberFormatException e) {e.printStackTrace();} catch (IOException e) {e.printStackTrace();}
    }
    
	public void cargarProgramaMemoria(Memoria memoriaVirtual){
		
		for(int i = 0; i < cantidadInstrucciones; i++){;
			memoriaVirtual.escrituraMemoria((inicioInstrucciones+i),instrucciones.get(i));
	    }
	    
	    for(int i = 0; i < cantidadDatos; i++){
	    	memoriaVirtual.escrituraMemoria((inicioDatos+i),datos.get(i));
	    }
	}
    
    public void Procesar(Memoria memoriaVirtual) throws IOException, InterruptedException{
    	
    	int quantum = 0;  
	    		
	    SalidaPantalla();	
	    		
	    PasarAListo();
	    	
	    SalidaPantalla();
	    		
	    while(ProcesosTerminados.size()<numeroDeProcesos){
	    	cargarProceso();
	    	quantum=0;
	    	while(ProcesoEjecutando.numeroInstrucciones>0 && quantum<5){
	    		SalidaPantalla();
	    		if(ProcesoEjecutando.error==ProcesoEjecutando.numeroInstrucciones){
	    			TerminarProceso();
	    			quantum = 0;
	    			continue;
	    		}
	    		if(ProcesoEjecutando.bloqueo==ProcesoEjecutando.numeroInstrucciones){
	    			BloquearProceso();
	    			continue;
	    		}
	    		
	    		instruccionString = memoriaVirtual.lecturaMemoria(ProcesoEjecutando.posicionInstruccion);
	    		instruccion = obtenerInstruccion(instruccionString);
				contadorPrograma.add(Integer.toString(ProcesoEjecutando.posicionInstruccion));
				registroInstrucciones.add(instruccionString);
				
				switch(instruccion.CodigoOperacion){
					case '1': CargaAC(instruccion.Operando, memoriaVirtual); break;
					case '2': EscribeAC(instruccion.Operando, memoriaVirtual); break;
					case '3': SumaAC(instruccion.Operando, memoriaVirtual); break;
					case '4': RestaAC(instruccion.Operando, memoriaVirtual); break;
					case '5': MultiplicacionAC(instruccion.Operando, memoriaVirtual); break;
					case '6': DivisionAC(instruccion.Operando, memoriaVirtual); break;
					case '7': LeeTXT(instruccion.Operando, memoriaVirtual); break;
					case '8': EscribeTXT(instruccion.Operando, memoriaVirtual); break;
					case '9': CopiaMem(instruccion.Operando, memoriaVirtual, ProcesoEjecutando.posicionInstruccion); break;
				}
	    		
	    		ProcesoEjecutando.numeroInstrucciones--;
	    		ProcesoEjecutando.posicionInstruccion++;
	    		quantum++;
	    		
	    		if(ProcesoEjecutando.numeroInstrucciones==0 || ProcesoEjecutando.error==ProcesoEjecutando.numeroInstrucciones){
	    			TerminarProceso();
	    			quantum = 0;
	    		}
	    				
	    		if(ProcesosBloqueados.size()>0){
	    			for(int i=0; i<ProcesosBloqueados.size(); i++){
	    				if(ProcesosBloqueados.get(i).quantumBloqueo>0){
	    					ProcesosBloqueados.get(i).quantumBloqueo--;
	    				}
	    				else if(ProcesosBloqueados.get(i).quantumBloqueo==0){
	    					DesbloquearProceso();
	    					if(ProcesosListos.size()==1 && ProcesoEjecutando.estado==0){
	    						quantum = 5;
	    					}
	    				}
	    			}
	    		}
	    		
	    		if(ProcesosListos.size()==0 && ProcesoEjecutando.estado==0){
	    			quantum=0;
	    		}
	    		
	    		if(ProcesosTerminados.size()==numeroDeProcesos && ProcesoEjecutando.estado==0){
	    			quantum=5;
	    			SalidaPantalla();
	    		}
	    	}

	    	
	    }
	    
	    ImprimirRegistros();
    }
    
    public void SalidaPantalla(){
    	
    	String cadenaSalida;
	    cadenaSalida="";
	    cadenaSalida+="Nuevo\t\tListo\t\tEjecucion\t\tBloqueado\t\tTerminado\n";
	    
	    for(int i=0; i<numeroDeProcesos;i++){
		
	    	if(Procesos.size()-i>0)
	    		cadenaSalida+=Procesos.get(i).idProceso +" "+ Procesos.get(i).numeroInstrucciones +" "+ Procesos.get(i).prioridad;
	    	else
	    		cadenaSalida+="\t";
			
	    	cadenaSalida+="\t";
			
	    	if(ProcesosListos.size()-i>0)
	    		cadenaSalida+=ProcesosListos.get(i).idProceso +" "+ ProcesosListos.get(i).numeroInstrucciones +" "+ ProcesosListos.get(i).prioridad;
	    	else
	    		if((i!=0 || ProcesoEjecutando.estado==0))
	    			cadenaSalida+="\t";
			
	    	cadenaSalida+="\t";
			
	    	if(ProcesoEjecutando.estado==1 && i==0)
	    		cadenaSalida+="\t"+ProcesoEjecutando.idProceso +" "+ ProcesoEjecutando.numeroInstrucciones+"\t";
	    	else
	    		cadenaSalida+="\t";
	    	
	    	if(ProcesoEjecutando.estado==0 && i==0 && ProcesosListos.size()>0)
	    		cadenaSalida+="\t";
	    	cadenaSalida+="\t";
			
	    	if(ProcesosBloqueados.size()-i>0)
	    		cadenaSalida+=ProcesosBloqueados.get(i).idProceso +" "+ ProcesosBloqueados.get(i).numeroInstrucciones+"\t";
	    	else
	    		cadenaSalida+="\t";
			
	    	cadenaSalida+="\t";
			
	    	if(ProcesosTerminados.size()-i>0)
	    		cadenaSalida+=ProcesosTerminados.get(i).idProceso +" "+ ProcesosTerminados.get(i).numeroInstrucciones;
	    	else
	    		cadenaSalida+="\t";
			
	    	cadenaSalida+="\n";
	    }
	    Ventana.dibujar(cadenaSalida);
    }
	
	public void intercambiarProcesos(Proceso procesoA, Proceso procesoB){
		Proceso procesoTemporal = new Proceso();
		
		procesoTemporal.idProceso = procesoA.idProceso;
	    procesoTemporal.numeroInstrucciones = procesoA.numeroInstrucciones;
	    procesoTemporal.prioridad = procesoA.prioridad;
	    procesoTemporal.error = procesoA.error;
	    procesoTemporal.bloqueo = procesoA.bloqueo;
	    procesoTemporal.quantumBloqueo = procesoA.quantumBloqueo;
	    procesoTemporal.posicionInstruccion = procesoA.posicionInstruccion;
	    
	    procesoA.idProceso = procesoB.idProceso;
	    procesoA.numeroInstrucciones = procesoB.numeroInstrucciones;
	    procesoA.prioridad = procesoB.prioridad;
	    procesoA.error = procesoB.error;
	    procesoA.quantumBloqueo = procesoB.quantumBloqueo;
	    procesoA.bloqueo = procesoB.bloqueo;
	    procesoA.posicionInstruccion = procesoB.posicionInstruccion;
	    
	    procesoB.idProceso = procesoTemporal.idProceso;
	    procesoB.numeroInstrucciones = procesoTemporal.numeroInstrucciones;
	    procesoB.prioridad = procesoTemporal.prioridad;
	    procesoB.error = procesoTemporal.error;
	    procesoB.quantumBloqueo = procesoTemporal.quantumBloqueo;
	    procesoB.bloqueo = procesoTemporal.bloqueo;
	    procesoB.posicionInstruccion = procesoTemporal.posicionInstruccion;
	}
	
	public void cargarProceso(){
		Proceso procesoTemporal = new Proceso();
		
		procesoTemporal.idProceso = ProcesoEjecutando.idProceso;
	    procesoTemporal.numeroInstrucciones = ProcesoEjecutando.numeroInstrucciones;
	    procesoTemporal.prioridad = ProcesoEjecutando.prioridad;
	    procesoTemporal.error = ProcesoEjecutando.error;
	    procesoTemporal.bloqueo = ProcesoEjecutando.bloqueo;
	    procesoTemporal.quantumBloqueo = ProcesoEjecutando.quantumBloqueo;
	    procesoTemporal.posicionInstruccion = ProcesoEjecutando.posicionInstruccion;
	    procesoTemporal.estado = 1;
	    
	    if(ProcesosListos.size()>0){
	    	ProcesoEjecutando.idProceso = ProcesosListos.get(0).idProceso;
	    	ProcesoEjecutando.numeroInstrucciones = ProcesosListos.get(0).numeroInstrucciones;
	    	ProcesoEjecutando.prioridad = ProcesosListos.get(0).prioridad;
	    	ProcesoEjecutando.error = ProcesosListos.get(0).error;
	    	ProcesoEjecutando.quantumBloqueo = ProcesosListos.get(0).quantumBloqueo;
	    	ProcesoEjecutando.bloqueo = ProcesosListos.get(0).bloqueo;
	    	ProcesoEjecutando.posicionInstruccion = ProcesosListos.get(0).posicionInstruccion;
	    
	    	ProcesosListos.remove(0);
	    }
	    
	    if(ProcesoEjecutando.estado > 0)
	    	ProcesosListos.add(procesoTemporal);
	    
	    ProcesoEjecutando.estado = 1;
	}
	
	public void BloquearProceso(){
		Proceso procesoTemporal = new Proceso();
		
		procesoTemporal.idProceso = ProcesoEjecutando.idProceso;
	    procesoTemporal.numeroInstrucciones = ProcesoEjecutando.numeroInstrucciones;
	    procesoTemporal.prioridad = ProcesoEjecutando.prioridad;
	    procesoTemporal.error = ProcesoEjecutando.error;
	    procesoTemporal.bloqueo = ProcesoEjecutando.bloqueo;
	    procesoTemporal.posicionInstruccion = ProcesoEjecutando.posicionInstruccion;
	    procesoTemporal.estado = 1;
	    procesoTemporal.quantumBloqueo = 10;
	    
	    ProcesosBloqueados.add(procesoTemporal);
	    
	    if(ProcesosListos.size()>0){ 
		    ProcesoEjecutando.idProceso = ProcesosListos.get(0).idProceso;
		    ProcesoEjecutando.numeroInstrucciones = ProcesosListos.get(0).numeroInstrucciones;
		    ProcesoEjecutando.prioridad = ProcesosListos.get(0).prioridad;
		    ProcesoEjecutando.error = ProcesosListos.get(0).error;
		    ProcesoEjecutando.bloqueo = ProcesosListos.get(0).bloqueo;
		    ProcesoEjecutando.posicionInstruccion = ProcesosListos.get(0).posicionInstruccion;
		    
		    ProcesosListos.remove(0);
	    }
	    
	    else{
	    	ProcesoEjecutando.idProceso = "";
		    ProcesoEjecutando.numeroInstrucciones = 1000;
		    ProcesoEjecutando.prioridad = 0;
		    ProcesoEjecutando.error = 0;
		    ProcesoEjecutando.bloqueo = 0;
		    ProcesoEjecutando.quantumBloqueo = 0;
		    ProcesoEjecutando.estado = 0;
	    }
   
	}
	
	public void DesbloquearProceso(){
		Proceso procesoTemporal = new Proceso();
		
		procesoTemporal.idProceso = ProcesosBloqueados.get(0).idProceso;
	    procesoTemporal.numeroInstrucciones = ProcesosBloqueados.get(0).numeroInstrucciones;
	    procesoTemporal.prioridad = ProcesosBloqueados.get(0).prioridad;
	    procesoTemporal.error = ProcesosBloqueados.get(0).error;
	    procesoTemporal.posicionInstruccion = ProcesosBloqueados.get(0).posicionInstruccion;
	    procesoTemporal.bloqueo = 0;
	    procesoTemporal.estado = 1;
	    procesoTemporal.quantumBloqueo = 0;
	    
	    ProcesosListos.add(procesoTemporal);
	    
	    ProcesosBloqueados.remove(0);
	       
	}
	
	public void TerminarProceso(){
		Proceso TemporalTerminado = new Proceso();
		TemporalTerminado.idProceso = ProcesoEjecutando.idProceso;
		TemporalTerminado.numeroInstrucciones = ProcesoEjecutando.numeroInstrucciones;
		TemporalTerminado.prioridad = ProcesoEjecutando.prioridad;
		TemporalTerminado.error = ProcesoEjecutando.error;
		TemporalTerminado.bloqueo = ProcesoEjecutando.bloqueo;
		TemporalTerminado.posicionInstruccion = ProcesoEjecutando.posicionInstruccion;
		ProcesosTerminados.add(TemporalTerminado);
				
		if(ProcesosListos.size()>0){
			ProcesoEjecutando.idProceso = ProcesosListos.get(0).idProceso;
		    ProcesoEjecutando.numeroInstrucciones = ProcesosListos.get(0).numeroInstrucciones;
		    ProcesoEjecutando.prioridad = ProcesosListos.get(0).prioridad;
		    ProcesoEjecutando.error = ProcesosListos.get(0).error;
		    ProcesoEjecutando.bloqueo = ProcesosListos.get(0).bloqueo;
		    ProcesoEjecutando.posicionInstruccion = ProcesosListos.get(0).posicionInstruccion;
		    
		    ProcesosListos.remove(0);
		}
		else
			ProcesoEjecutando.estado=0;
		
	}
	
	public void PasarAListo(){
		int numProcesos = Procesos.size();
		for(int j=0;j<numProcesos; j++){
			ProcesosListos.add(Procesos.get(j));
		}
			
		Procesos.removeAllElements();
	}
	
	public Instruccion obtenerInstruccion(String instruccionStr){
		Instruccion instrucciontemporal = new Instruccion();
		instrucciontemporal.CodigoOperacion = instruccionStr.charAt(0);
		instrucciontemporal.Operando = instruccionStr.substring(1, 4);
		return instrucciontemporal;
	}
	
	public void CargaAC(String operando, Memoria memoriaVirtual){
		String valoraCargar = memoriaVirtual.lecturaMemoria(Integer.parseInt(operando));
		valoraCargar = llenarString(valoraCargar);
		acumulador.add(valoraCargar);
		ultimo++;
	}
	
	public void EscribeAC(String operando, Memoria memoriaVirtual){
		memoriaVirtual.escrituraMemoria(Integer.parseInt(operando), acumulador.get(ultimo));
		acumulador.add(acumulador.get(ultimo));
		ultimo++;
	}
	
	public void SumaAC(String operando, Memoria memoriaVirtual){
		String valoraCargar = memoriaVirtual.lecturaMemoria(Integer.parseInt(operando));
		if(acumulador.isEmpty()){
			valoraCargar = Integer.toString(0+Integer.parseInt(valoraCargar));
		}
		else{
			valoraCargar = Integer.toString(Integer.parseInt(acumulador.get(ultimo))+Integer.parseInt(valoraCargar));
		}
		valoraCargar = llenarString(valoraCargar);
		acumulador.add(valoraCargar);
		ultimo++;
	}
	
	public void RestaAC(String operando, Memoria memoriaVirtual){
		String valoraCargar = memoriaVirtual.lecturaMemoria(Integer.parseInt(operando));
		valoraCargar = Integer.toString(Integer.parseInt(acumulador.get(ultimo))-Integer.parseInt(valoraCargar));
		valoraCargar = llenarString(valoraCargar);
		acumulador.add(valoraCargar);
		ultimo++;
	}
	
	public void MultiplicacionAC(String operando, Memoria memoriaVirtual){
		String valoraCargar = memoriaVirtual.lecturaMemoria(Integer.parseInt(operando));
		valoraCargar = Integer.toString(Integer.parseInt(acumulador.get(ultimo))*Integer.parseInt(valoraCargar));
		valoraCargar = llenarString(valoraCargar);
		acumulador.add(valoraCargar);
		ultimo++;
	}
	
	public void DivisionAC(String operando, Memoria memoriaVirtual){
		String valoraCargar = memoriaVirtual.lecturaMemoria(Integer.parseInt(operando));
		valoraCargar = Integer.toString(Integer.parseInt(acumulador.get(ultimo))*Integer.parseInt(valoraCargar));
		valoraCargar = llenarString(valoraCargar);
		acumulador.add(valoraCargar);
		ultimo++;
	}
	
	public void LeeTXT(String operando, Memoria memoriaVirtual)throws IOException{
		FileReader archivoTexto = new FileReader("archivo.txt");
	    BufferedReader bufferLectura = new BufferedReader(archivoTexto);
	    int valorAlmacenado = Integer.parseInt(bufferLectura.readLine().trim());
	    bufferLectura.close();
	    String valoraCargar = Integer.toString(valorAlmacenado+Integer.parseInt(acumulador.get(ultimo)));
	    valoraCargar = llenarString(valoraCargar);
		acumulador.add(valoraCargar);
		ultimo++;
	}
	
	public void EscribeTXT(String operando, Memoria memoriaVirtual) throws IOException{
		File archivo = new File("archivo.txt");
        BufferedWriter bw;
        bw = new BufferedWriter(new FileWriter(archivo));
		bw.write(acumulador.get(ultimo));
		bw.close();
		acumulador.add(acumulador.get(ultimo));
		ultimo++;
	}
	
	public void CopiaMem(String operando, Memoria memoriaVirtual, int posicion) throws IOException{
		File archivo = new File("memoriaSecundaria.txt");
        BufferedWriter bw;
        bw = new BufferedWriter(new FileWriter(archivo,true));
        bw.append(Integer.toString(posicion));
        for(int i=0; i<1000; i++){
        	String instruccionMemoria;
        	instruccionMemoria = memoriaVirtual.lecturaMemoria(i);
			if(!instruccionMemoria.equals("0000")){
				bw.append("\r\n"+i+"\t"+instruccionMemoria);
			}
		}
        bw.append("\r\n\r\n");
		bw.close();

		acumulador.add(acumulador.get(ultimo));
		ultimo++;
	}
	
	public String llenarString(String operando){
		switch(operando.length()){
			case 1: operando = "000"+operando; break;
			case 2: operando = "00"+operando; break;
			case 3: operando = "0"+operando; break;
		}
		return operando;
	}
	
	public void ImprimirRegistros() throws IOException{
		File archivo = new File("tabla.txt");
        BufferedWriter bw;
        bw = new BufferedWriter(new FileWriter(archivo,true));
        bw.append("PC\tIR\tAcumulador");
		System.out.println("PC\tIR\tAcumulador");
		for(int i=0; i<=ultimo; i++){
			System.out.println(contadorPrograma.get(i)+"\t"+registroInstrucciones.get(i)+"\t"+acumulador.get(i));
			bw.append("\r\n"+contadorPrograma.get(i)+"\t"+registroInstrucciones.get(i)+"\t"+acumulador.get(i));
		}
		bw.append("\r\n\r\n");
		bw.close();
	}
	
	public static void main(String[] args) throws IOException, InterruptedException{
		Memoria memoriaVirtual = new Memoria();
    	GestorDeProcesos abrir = new GestorDeProcesos(memoriaVirtual);
    }
}