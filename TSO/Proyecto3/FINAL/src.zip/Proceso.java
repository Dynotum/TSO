public class Proceso {
	String idProceso;
	int numeroInstrucciones;
	int prioridad;
	int error;
	int bloqueo;
	int estado;
	int quantumBloqueo;
	int posicionInstruccion;
}
